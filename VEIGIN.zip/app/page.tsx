import { Suspense } from "react";
import Link from "next/link";
import { getHomeProducts } from "@/lib/products";
import ScatterField from "@/components/ScatterField";

async function HomeContent() {
  const products = await getHomeProducts();
  return (
    <main className="mx-auto w-full max-w-[1400px] px-4">
      <div className="relative min-h-[calc(100vh-4rem)] flex items-center">
        <div className="grid gap-8 lg:grid-cols-[1fr_55%] lg:items-center lg:gap-12 w-full">
          <div className="z-10">
            <h1 className="font-display font-light text-5xl leading-tight text-foreground sm:text-6xl">
              Wear <span className="font-bold text-accent">the dark.</span>
            </h1>
            <p className="mt-4 font-display font-medium text-sm uppercase tracking-[0.2em] text-muted">
              GOTHIC HERO. DARK BY DESIGN.
            </p>
            <Link
              href="/products"
              className="mt-8 inline-flex items-center rounded-2xl transition-transform duration-300 ease-in-out hover:scale-112 gap-3 border border-foreground px-6 py-3 font-price text-sm uppercase tracking-[0.14em] text-foreground transition-colors hover:bg-foreground hover:text-background focus-visible:bg-foreground focus-visible:text-background"
            >
              Explore the collection
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={1.5}
                strokeLinecap="square"
                aria-hidden="true"
                className="size-4"
              >
                <path d="M5 12h14M13 6l6 6-6 6" />
              </svg>
            </Link>
            {products.length === 0 && (
              <p className="mt-6 font-display text-xs text-muted">
                No products available yet.
              </p>
            )}
          </div>
          <div className="lg:col-start-2">
            <ScatterField products={products} />
          </div>
        </div>
      </div>
    </main>
  );
}

export default function Page() {
  return (
    <Suspense fallback={<div className="mx-auto max-w-[1400px] px-4 min-h-[calc(100vh-4rem)] flex items-center" />}>
      <HomeContent />
    </Suspense>
  );
}