"use client";

import { useEffect, useState } from "react";
import { motion, useReducedMotion, useMotionValue, useSpring } from "motion/react";
import {
  CARD_WIDTH_PCT,
  FIELD_ASPECT,
  displacedFor,
  type HomeProduct,
} from "@/lib/scatter";

type Props = {
  products: HomeProduct[];
};

function ScatterCard({
  product,
  index,
  isOrganized,
  reduced,
  organizedX,
  organizedY,
  scatteredX,
  scatteredY,
  scatteredRot,
}: {
  product: HomeProduct;
  index: number;
  isOrganized: boolean;
  reduced: boolean;
  organizedX: number;
  organizedY: number;
  scatteredX: number;
  scatteredY: number;
  scatteredRot: number;
}) {
  const [revealed, setRevealed] = useState(false);

  const organizedRot = 0;

  // Target values that change based on isOrganized
  const targetX = useMotionValue(isOrganized ? organizedX : scatteredX);
  const targetY = useMotionValue(isOrganized ? organizedY : scatteredY);
  const targetRotate = useMotionValue(isOrganized ? organizedRot : scatteredRot);

  // Springy motion values that follow the targets
  const x = useSpring(targetX, {
    stiffness: reduced ? 100000 : 180,
    damping: reduced ? 10000 : 22,
    mass: 0.9,
  });
  const y = useSpring(targetY, {
    stiffness: reduced ? 100000 : 180,
    damping: reduced ? 10000 : 22,
    mass: 0.9,
  });
  const rotate = useSpring(targetRotate, {
    stiffness: reduced ? 100000 : 180,
    damping: reduced ? 10000 : 22,
    mass: 0.9,
  });

  // Update targets when isOrganized changes
  useEffect(() => {
    targetX.set(isOrganized ? organizedX : scatteredX);
    targetY.set(isOrganized ? organizedY : scatteredY);
    targetRotate.set(isOrganized ? organizedRot : scatteredRot);
  }, [isOrganized, organizedX, organizedY, scatteredX, scatteredY, organizedRot, scatteredRot, targetX, targetY, targetRotate]);

  const onClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    const isTouch =
      typeof window !== "undefined" &&
      window.matchMedia("(hover: none)").matches;
    if (isTouch && !revealed) {
      e.preventDefault();
      setRevealed(true);
    }
  };

  return (
    <motion.a
      href={`/products/${product.slug}`}
      onClick={onClick}
      suppressHydrationWarning
      className="group absolute block focus:outline-none"
      style={{
        left: `${product.homeX}%`,
        top: `${product.homeY}%`,
        width: "clamp(190px, 15vw, 300px)",
        transformOrigin: "center center",
        x,
        y,
        rotate,
      }}
      whileHover={{ scale: 1.02 }}
      whileFocus={{ scale: 1.02 }}
    >
      <div
        className="relative rounded-none border border-silver/30 bg-panel"
        style={{ aspectRatio: "3 / 4" }}
      >
        {/* crimson corner tab */}
        <span
          className="absolute right-0 top-0 z-10 block h-3 w-3 bg-accent"
          aria-hidden="true"
        />
        {/* photo placeholder */}
        <span className="absolute inset-0 flex items-center justify-center font-mono text-[10px] uppercase tracking-[0.3em] text-silver/50">
          PHOTO
        </span>
      </div>

      {/* upright label - counter-rotated to stay readable */}
      <span
        className={`pointer-events-none absolute left-1/2 top-full z-20 mt-2 w-max max-w-[42vw] -translate-x-1/2 text-center transition-opacity duration-150 ${
          revealed
            ? "opacity-100"
            : "opacity-0 group-hover:opacity-100 group-focus-within:opacity-100"
        }`}
        style={{ transform: `rotate(${-product.homeRot}deg)` }}
      >
        <span className="block font-name-face text-base leading-tight text-bone">
          {product.name}
        </span>
        <span className="mt-0.5 block font-price text-sm text-accent">
          PKR {product.price}
        </span>
      </span>
    </motion.a>
  );
}

export default function ScatterField({ products }: Props) {
  const reduced = useReducedMotion();
  const [isOrganized, setIsOrganized] = useState(false);

  // Detect touch device (lazy init to avoid setState in effect)
  const [isTouch] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia("(hover: none)").matches;
  });

  // Pre-calculate scattered (displaced) and organized positions during render
  const positions = (function computePositions() {
    if (products.length === 0) return { scattered: [], organized: [] };

    // Scattered positions = displacedFor (entrance positions, now the resting state)
    const scattered = products.map((p) => displacedFor(p.id, p.homeX, p.homeY));

    // Organized grid positions: 2 columns, centered in the field
    const cols = 2;
    const cardWidthPct = CARD_WIDTH_PCT;
    const gapPct = 4;
    const totalWidth = cols * cardWidthPct + (cols - 1) * gapPct;
    const startX = (100 - totalWidth) / 2;

    const organized: Array<{ x: number; y: number }> = [];
    products.forEach((_, i) => {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const x = startX + col * (cardWidthPct + gapPct) + cardWidthPct / 2;
      const y = 20 + row * (cardWidthPct / 0.75 + 8);
      organized.push({ x, y });
    });

    return { scattered, organized };
  })();

  const handleMouseEnter = () => {
    if (!reduced) setIsOrganized(true);
  };

  const handleMouseLeave = () => {
    if (!reduced) setIsOrganized(false);
  };

  const handleFocus = () => {
    if (!reduced) setIsOrganized(true);
  };

  const handleBlur = (e: React.FocusEvent<HTMLDivElement>) => {
    if (!e.currentTarget.contains(e.relatedTarget as Node | null)) {
      if (!reduced) setIsOrganized(false);
    }
  };

  const handleTouchToggle = () => {
    setIsOrganized((prev) => !prev);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      handleTouchToggle();
    }
  };

  return (
    <section
      className="relative mx-auto w-full max-w-[770px] overflow-hidden"
      style={{ aspectRatio: String(FIELD_ASPECT) }}
      aria-label="Veigin homepage products"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onFocus={handleFocus}
      onBlur={handleBlur}
      onKeyDown={handleKeyDown}
      tabIndex={0}
    >
      {/* Central trigger zone (desktop pointer) - covers the card area */}
      <div
        className="absolute inset-0 z-10"
        aria-hidden="true"
      />

      {/* Touch toggle button */}
      {isTouch && (
        <button
          type="button"
          onClick={handleTouchToggle}
          className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 px-4 py-2 font-display text-xs uppercase tracking-[0.14em] text-bone bg-panel border border-silver/30 rounded-none"
          aria-pressed={isOrganized}
          aria-label={isOrganized ? "View scattered" : "View aligned"}
        >
          {isOrganized ? "Scatter" : "Align"}
        </button>
      )}

      {products.map((p, i) => {
        const scattered = positions.scattered[i];
        const organized = positions.organized[i];
        return (
          <ScatterCard
            key={p.id}
            product={p}
            index={i}
            isOrganized={isOrganized}
            reduced={!!reduced}
            organizedX={organized?.x ?? p.homeX}
            organizedY={organized?.y ?? p.homeY}
            scatteredX={scattered?.x ?? 0}
            scatteredY={scattered?.y ?? 0}
            scatteredRot={scattered?.rot ?? 0}
          />
        );
      })}
    </section>
  );
}